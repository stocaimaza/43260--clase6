import Promesas from "./componentes/Promesas/Promesas"
import Map from "./componentes/Map/Map"
import Simpsons from "./componentes/Simpsons/Simpsons"

const App = () => {
  return (
    <>
      <Promesas/>
      <Map/>
      <Simpsons/>
    </>
  )
}

export default App