//Método MAP: 
//En React lo utilizamos generalmente para crear una lista de componentes a partir de un array de datos. 

const Map = () => {
  const productos = [
    {id: 1, nombre: "Notebook", precio: 1000},
    {id: 2, nombre: "Teclado", precio: 100},
    {id: 3, nombre: "Mouse", precio: 300},
    {id: 4, nombre: "Monitor", precio: 5000},
  ]


  return (
    <div>
        <h2>Productos de Computación: </h2>
        <ul>
            {
              productos.map((producto, index) => (
                <li key={index}>
                  <span> {producto.nombre} </span>
                  <span> {producto.precio} </span>
                </li>
              ))
            }
        </ul>
    </div>
  )
}

export default Map