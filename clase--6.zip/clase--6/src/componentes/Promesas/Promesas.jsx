//Programación Sincrónica y Asincrónica. 

//La programación sincrónica ejecuta una tarea a la vez, en orden secuencial.

//La programación asincrónica ejecuta varias tareas al mismo tiempo, en orden no secuencial. 

//Como practicamos la programación asíncrona: setTimeout(). 

//Promesas: es un objeto de JS que representa un evento a futuro.
//En general representa el resultado eventual de una petición asíncrona. 

//Las promesas tienen tres estados: pendiente, cumplida o rechazada. 


const Promesas = () => {
    //Programación sincrónica: 
    console.log("tarea 1");
    console.log("tarea 2");

    //Programación asíncrona: 

    setTimeout( () => {
        console.log("Tarea A");
    }, 2000)

    setTimeout( () => {
        console.log("Tarea B");
    }, 2000)

    //Promesas: 

    const tusFalsasPromesas = (estado) => {
        return new Promise((resolve, reject)=> {
            if(estado) {
                resolve("Promesa Cumplida, te llegó el ragalo que querias");
            } else {
                reject("Y se marchó...");
            }
        })
    }

    console.log(tusFalsasPromesas(false));

    //THEN Y CATCH
    //Podemos concatenar dos métodos que me permiten ejecutar una función cuando la promesa se cumple o se rechaza. 
    //THEN se ejecuta cuando la promesa se cumple.
    //CATCH se ejecuta cuando la promesa se rechaza. 
    //FINALLY se ejecuta. 

    tusFalsasPromesas(true)
        .then(respuesta => console.log("Sii se cumple!!", respuesta))
        .catch(error => console.log("Todo mal, vamos a morir", error))

    
    //Ahora practiquemos con un array de datos: 

    const array = ["Tinki Winki", "Lala", "Dipsy", "Po"];

    const solicitarTeletubbies = (estado) => {
        return new Promise((resuelto, rechazado) => {
            if(estado) {
                resuelto(array);
            } else {
                rechazado("No hay teletubbies en la tele hoy");
            }
        })
    }

    solicitarTeletubbies(false)
        .then(resuelto => {
            console.table(resuelto);
        })
       







  return (
    <div>Promesas</div>
  )
}

export default Promesas